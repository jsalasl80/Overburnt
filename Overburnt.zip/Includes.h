#ifndef INCLUDES
#define INCLUDES

#include <fstream>
#include <sstream>
#include <iostream>
#include <cstdio>

#include <vector>
#include <map>
#include <unordered_map>
#include <queue>

#include <string>
#include <cstring>

#include <stdexcept>
#include <chrono>
#include <thread>
#include <mutex>
#include <algorithm>
#include <functional>
#include <future>

#include <random>

#endif